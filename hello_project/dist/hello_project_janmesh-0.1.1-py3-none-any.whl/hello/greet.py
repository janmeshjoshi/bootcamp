def say_hello(name="World"):
    return f'Hello, {name}!'